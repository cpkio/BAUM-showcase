'use strict'
const asciidoctor = require('@asciidoctor/core')()

module.exports = (text) => {
  return asciidoctor.convert(text, {
        // extensions_registry: registry,
        // safe: 'server'
        doctype: 'inline',
        standalone: true
      });
}
