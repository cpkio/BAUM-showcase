'use strict'
module.exports = (client) => {
  if (!(typeof client === 'undefined')) {
    return client.split(',').map((item) => item.toUpperCase().trim()).map((item) => ` <span class="tag">${item}</span>`).join('');
  }
}
