'use strict'

module.exports = (context) => {
  return JSON.stringify(context);
}
